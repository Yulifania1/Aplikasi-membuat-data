<?php 

$host       ="localhost";
$user       ="root";
$pass       ="";
$db         ="biodata kelas";

$koneksi = mysqli_connect($host,$user,$pass,$db);
if (! $koneksi){ //cek koneksi 
    die("tidak tersambung ke database");

}
  $Nama    ="";
  $Tplahir ="";
  $Alamat  ="";
  $Hobi    ="";
  $Cita    ="";  
  $Jml     ="";
  $Idkelas ="";
  $Idagama ="";
  $sukses  ="";
  $error   ="";

if(isset ($_POST['Simpan'])){ 
 $Nama       =$_POST['Nama'];
 $Tplahir    =$_POST['Tplahir'];
 $Alamat     =$_POST['Alamat'];
 $Hobi       =$_POST['Hobi'];
 $Cita       =$_POST['Cita'];
 $Jml        =$_POST['Jml'];
 $Idkelas    =$_POST['Idkelas'];
 $Idagama    =$_POST['Idagama'];

   if( $Nama && $Tplahir && $Alamat && $Hobi && $Cita && $Jml && $Idkelas && $Idagama){
       $sql1 = "insert into Biodata Kelas (Nama,Tplahir,Alamat,Hobi,Cita,Jml,Idkelas,Idagama) values ('$Nama','$Tplahir','$Alamat','$Hobi','$Cita','$Jml','$Idkelas','$Idagama')";
       $q1   = mysqli_query($koneksi,$sql1);
       if($q1){
        $sukses    ="Berhasil memasukkan data baru";
   }    else{
        $eroor     ="gagal memasukkan data" ;  
   }
    }else{
        $eroor ="Silahkan masukkan semua data";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equive="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        .mx-auto {width:800px}
        .card { margin-top: 10}
        </style>
</head>
<body>
    <div class="mx-auto">
        <!-- untuk memasukkan data-->
               <div class="card">
              <div class="card-header">
                  Creat/ Edit Data
             <div class="card-body">
                <?php
            if($error){
               ?>
                    <div class="alert alert-danger" role="alert">
                       <?php echo $error ?>
                        </div>
                   <?php
                     }
                     ?> 

<?php
            if($sukses){
               ?>
                    <div class="alert alert-success" role="alert">
                       <?php echo $sukses ?>
                        </div>
                   <?php
                     }
                     ?> 
                   <from action="" method="POST">
                   <div class="form-group row">
                   <label for="Nama" class="col-sm-2 col-form-label">Nama</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Nama" name="Nama" value="<?php echo $Nama?>">
    </div>
  </div>

  <div class="form-group row">
                   <label for="Tplahir" class="col-sm-2 col-form-label">Tempat Tanggal Lahir</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Tplahir" name="Tplahir" value="<?php echo $Tplahir?>">
    </div>
  </div>

  <div class="form-group row">
                   <label for="Alamat" class="col-sm-2 col-form-label">Alamat</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Alamat" name="Alamat" value="<?php echo $Alamat?>">
    </div>
  </div>

  <div class="form-group row">
                   <label for="Cita" class="col-sm-2 col-form-label">Cita - Cita</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Cita"  name="Cita" value="<?php echo $Cita?>">
    </div>
  </div>

  <div class="form-group row">
                   <label for="Jml" class="col-sm-2 col-form-label">Jumlah Saudara</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Jml" name="jml" value="<?php echo $Jml?>">
    </div>
  </div>
  <div class="form-group row">
                   <label for="Idkelas" class="col-sm-2 col-form-label">Id Kelas</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="Idkelas" name="Idkelas" value="<?php echo $Idkelas?>">
    </div>
  </div>

  <div class="form-group row">
                   <label for="Idagama" class="col-sm-2 col-form-label">Id Agama</label>
                   <div class="col-sm-10">
                  <input type="text"  class="form-control" id="IDagama" name="Idagama" value="<?php echo $Idagama?>">
    </div>
  </div>
     <div class="col-12">
        <input type="submit" name="Simpan" value="Simpan Data" class="btn btn-primary">
     </div>
                   </from>
  </div>
</div>

            <!--untuk mengeluarkan data-->
         <div class="card">
              <div class="card-header text-white bg-secondary">
                  Data Siswa
             <div class="card-body">
               <table class="table">
                <thead>
                    <tr>
                    <th scoope="col">#</tr>
                    <th scope="col">Nama</th>
                    <th scope="col">Tplahir</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Cita</th>
                    <th scope="col">Jml</th>
                    <th scope="col">Idkelas</th>
                    <th scope="col">Idagama</th>
                    </th>
                    <tbody>
                        <?php
                       $sql2 = "select * from biodata siswa otder by id desc";
                       $q2   = mysqli_query($koneksi,$q2);
                       $urut = 1;
                         while($r2 = mysqli_fetch_array($q2)){
                             $id         = $r2['id'];
                             $Nama       =$r2['Nama'];
                             $Tplahir    =$r2['Tplahir'];
                             $Alamat     =$r2['Alamat'];
                             $Hobi       =$r2['Hobi'];
                             $Cita       =$r2['Cita'];
                             $Jml        =$r2['Jml'];
                             $Idkelas    =$rs2['Idkelas'];
                             $Idagama    =$rs2['Idagram'];
                             
                             ?>
                             <tr> 
                                <th scope="row"></th><?php echo $urut++?>
                             </tr>
                             ?>
                         <?php } ?>
                        
                    </tbody>
            </thead>
               </table>
                   
  </div>
</div>
</div>
</body>

    
    
   